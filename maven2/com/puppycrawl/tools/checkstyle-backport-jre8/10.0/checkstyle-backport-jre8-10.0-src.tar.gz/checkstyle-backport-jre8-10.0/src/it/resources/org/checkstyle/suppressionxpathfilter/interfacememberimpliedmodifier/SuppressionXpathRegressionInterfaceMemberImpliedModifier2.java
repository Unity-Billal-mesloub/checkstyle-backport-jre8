package org.checkstyle.suppressionxpathfilter.interfacememberimpliedmodifier;

public interface SuppressionXpathRegressionInterfaceMemberImpliedModifier2 {
    abstract void setData(); // warn
}
