package org.checkstyle.suppressionxpathfilter.interfacememberimpliedmodifier;

public interface SuppressionXpathRegressionInterfaceMemberImpliedModifier3 {
    public interface Data {} // warn
}
