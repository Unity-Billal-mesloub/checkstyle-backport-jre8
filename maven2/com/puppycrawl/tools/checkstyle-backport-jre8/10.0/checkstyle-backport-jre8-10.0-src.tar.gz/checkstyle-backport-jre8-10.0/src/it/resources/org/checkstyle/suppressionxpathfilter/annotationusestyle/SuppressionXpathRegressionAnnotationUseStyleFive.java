package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@SuppressWarnings(value={"foo", "bar"}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleFive {

}
