package org.checkstyle.suppressionxpathfilter.importorder;

import java.util.List;
import static org.junit.After.*;
import java.util.Date; // warn

public class SuppressionXpathRegressionImportOrderFive {
    // code
}
