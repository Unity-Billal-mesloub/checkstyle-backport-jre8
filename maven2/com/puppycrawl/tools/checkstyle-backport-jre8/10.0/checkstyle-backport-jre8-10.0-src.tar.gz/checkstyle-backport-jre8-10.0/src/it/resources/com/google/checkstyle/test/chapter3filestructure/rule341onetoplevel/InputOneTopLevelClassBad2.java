package com.google.checkstyle.test.chapter3filestructure.rule341onetoplevel;

public enum InputOneTopLevelClassBad2 {} //ok

interface FooIn {} // warn

class FooClass {} // warn


