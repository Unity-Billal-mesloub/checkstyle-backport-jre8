package org.checkstyle.suppressionxpathfilter.interfaceistype;

public interface SuppressionXpathRegressionInterfaceIsType1 { // warn
    int a = 3;
}
