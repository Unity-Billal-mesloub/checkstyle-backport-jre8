package org.checkstyle.suppressionxpathfilter.indentation;

public class SuppressionXpathRegressionIndentationTestOne {
void wrongIntend() { // warn
    }
}
