package org.checkstyle.suppressionxpathfilter.interfaceistype;

public interface SuppressionXpathRegressionInterfaceIsType2 { // warn

}
