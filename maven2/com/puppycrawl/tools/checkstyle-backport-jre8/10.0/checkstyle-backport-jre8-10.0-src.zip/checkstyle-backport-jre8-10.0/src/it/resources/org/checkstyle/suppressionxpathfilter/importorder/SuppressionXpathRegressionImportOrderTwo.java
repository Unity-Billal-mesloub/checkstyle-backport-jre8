package org.checkstyle.suppressionxpathfilter.importorder;

import java.util.List;

import java.util.Set; // warn

public class SuppressionXpathRegressionImportOrderTwo {
    // code
}
