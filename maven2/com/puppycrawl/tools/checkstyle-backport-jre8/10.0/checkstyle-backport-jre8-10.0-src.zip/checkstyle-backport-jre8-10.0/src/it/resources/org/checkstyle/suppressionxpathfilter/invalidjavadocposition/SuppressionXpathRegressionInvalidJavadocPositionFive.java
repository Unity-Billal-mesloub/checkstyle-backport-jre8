package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

public class SuppressionXpathRegressionInvalidJavadocPositionFive {
    public void foo() {
        /** // warn
         * Javadoc comment
         */
    }
}
