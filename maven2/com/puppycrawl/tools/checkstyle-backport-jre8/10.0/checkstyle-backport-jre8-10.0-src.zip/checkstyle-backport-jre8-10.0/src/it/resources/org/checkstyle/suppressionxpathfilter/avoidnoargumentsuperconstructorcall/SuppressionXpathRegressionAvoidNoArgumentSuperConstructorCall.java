package org.checkstyle.suppressionxpathfilter.avoidnoargumentsuperconstructorcall;

public class SuppressionXpathRegressionAvoidNoArgumentSuperConstructorCall {
    SuppressionXpathRegressionAvoidNoArgumentSuperConstructorCall() {
        super(); //warn
    }
}
