package org.checkstyle.suppressionxpathfilter.illegalthrows;

public class SuppressionXpathRegressionIllegalThrowsOne {
    public void sayHello() throws RuntimeException //warn
    {
    }
}
