package org.checkstyle.suppressionxpathfilter.invalidjavadocposition;

public class SuppressionXpathRegressionInvalidJavadocPositionFour {
    /** // warn
     * Javadoc Comment
     */
}
