package org.checkstyle.suppressionxpathfilter.indentation;

public class SuppressionXpathRegressionIndentationTestTwo {
    void test() {} // warn
}
