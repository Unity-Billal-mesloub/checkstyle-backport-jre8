package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@Deprecated
@SuppressWarnings({""}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleOne {

}
