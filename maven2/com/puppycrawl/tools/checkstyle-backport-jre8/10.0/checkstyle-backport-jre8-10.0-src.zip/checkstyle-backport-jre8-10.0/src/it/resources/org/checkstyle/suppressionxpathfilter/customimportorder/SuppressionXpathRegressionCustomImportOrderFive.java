package org.checkstyle.suppressionxpathfilter.customimportorder;

import static java.util.Arrays.sort;

import java.io.File;
import java.io.FileInputStream;
import static java.lang.Math.PI; // warn
import java.util.HashMap;
import java.util.Scanner;

public class SuppressionXpathRegressionCustomImportOrderFive {
    // code
}
