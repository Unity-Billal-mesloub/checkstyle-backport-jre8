package org.checkstyle.suppressionxpathfilter.interfacememberimpliedmodifier;

public interface SuppressionXpathRegressionInterfaceMemberImpliedModifier1 {
    public static String str = "random string"; // warn
}
