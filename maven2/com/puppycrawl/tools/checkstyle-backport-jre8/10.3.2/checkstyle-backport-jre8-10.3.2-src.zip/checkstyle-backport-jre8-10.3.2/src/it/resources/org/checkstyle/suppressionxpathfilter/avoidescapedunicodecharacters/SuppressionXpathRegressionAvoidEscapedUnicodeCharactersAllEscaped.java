package org.checkstyle.suppressionxpathfilter.avoidescapedunicodecharacters;

public class SuppressionXpathRegressionAvoidEscapedUnicodeCharactersAllEscaped {
    private String unitAbbrev9 = "\u03bcs"; /* warn */
    String allCharactersEscaped = "\u03bc\u03bc";
}
