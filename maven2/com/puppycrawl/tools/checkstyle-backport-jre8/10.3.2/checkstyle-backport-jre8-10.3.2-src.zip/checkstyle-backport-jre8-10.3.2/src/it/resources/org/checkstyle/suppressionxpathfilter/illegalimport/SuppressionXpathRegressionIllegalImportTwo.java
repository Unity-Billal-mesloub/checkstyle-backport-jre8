package org.checkstyle.suppressionxpathfilter.illegalimport;

import static java.lang.Math.pow; // warn

public class SuppressionXpathRegressionIllegalImportTwo {
}
