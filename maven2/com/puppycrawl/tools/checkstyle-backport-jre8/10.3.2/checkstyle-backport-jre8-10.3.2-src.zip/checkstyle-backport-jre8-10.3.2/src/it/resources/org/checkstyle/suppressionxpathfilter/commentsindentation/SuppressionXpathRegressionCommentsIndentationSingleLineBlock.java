package org.checkstyle.suppressionxpathfilter.commentsindentation;

public class SuppressionXpathRegressionCommentsIndentationSingleLineBlock {
    public void foo() {
// Single Line
// block Comment // warn
    }
}
