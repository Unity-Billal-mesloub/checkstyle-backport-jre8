package org.checkstyle.suppressionxpathfilter.constantname;

public class SuppressionXpathRegressionConstantNameWithBeginningUnderscore {
    private static final String _CONSTANT = "a"; // warn
}
