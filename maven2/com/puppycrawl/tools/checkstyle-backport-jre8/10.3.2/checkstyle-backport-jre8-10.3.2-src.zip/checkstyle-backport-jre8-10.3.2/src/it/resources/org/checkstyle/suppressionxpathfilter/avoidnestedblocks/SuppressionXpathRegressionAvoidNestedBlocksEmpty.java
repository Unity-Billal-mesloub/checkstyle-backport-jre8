package org.checkstyle.suppressionxpathfilter.avoidnestedblocks;

public class SuppressionXpathRegressionAvoidNestedBlocksEmpty {

    void empty() {
        {} // warn
    }
}
