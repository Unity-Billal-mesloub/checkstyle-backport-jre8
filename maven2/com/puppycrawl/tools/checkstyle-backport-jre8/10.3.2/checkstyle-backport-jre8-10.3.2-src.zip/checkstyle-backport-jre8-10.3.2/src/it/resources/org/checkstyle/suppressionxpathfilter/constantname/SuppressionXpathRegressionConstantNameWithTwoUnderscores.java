package org.checkstyle.suppressionxpathfilter.constantname;

public class SuppressionXpathRegressionConstantNameWithTwoUnderscores {
    private static final int BAD__NAME = 3; // warn
}
