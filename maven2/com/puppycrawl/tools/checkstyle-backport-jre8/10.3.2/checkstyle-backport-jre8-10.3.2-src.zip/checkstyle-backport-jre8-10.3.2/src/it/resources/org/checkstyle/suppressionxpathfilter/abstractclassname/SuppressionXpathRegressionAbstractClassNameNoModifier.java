package org.checkstyle.suppressionxpathfilter.abstractclassname;

public class SuppressionXpathRegressionAbstractClassNameNoModifier {
    class AbstractMyClass { // warn
    }
}
