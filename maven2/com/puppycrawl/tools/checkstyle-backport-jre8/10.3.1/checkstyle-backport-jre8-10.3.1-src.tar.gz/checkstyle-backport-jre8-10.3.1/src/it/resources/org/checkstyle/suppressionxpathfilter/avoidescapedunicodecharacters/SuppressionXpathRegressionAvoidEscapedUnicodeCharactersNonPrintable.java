package org.checkstyle.suppressionxpathfilter.avoidescapedunicodecharacters;

public class SuppressionXpathRegressionAvoidEscapedUnicodeCharactersNonPrintable {
    private String unitAbbrev9 = "\u03bcs"; /* warn */
    private String nonPrintableCharacter = "\ufeff";
}
