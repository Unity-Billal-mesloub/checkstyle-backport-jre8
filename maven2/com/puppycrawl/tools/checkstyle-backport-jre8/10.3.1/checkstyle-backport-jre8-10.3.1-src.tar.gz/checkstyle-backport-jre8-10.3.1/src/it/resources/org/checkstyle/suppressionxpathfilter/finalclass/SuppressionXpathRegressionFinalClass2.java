package org.checkstyle.suppressionxpathfilter.finalclass;

public class SuppressionXpathRegressionFinalClass2 {
    class Test { // warn
        private Test(){

        }
    }
}
