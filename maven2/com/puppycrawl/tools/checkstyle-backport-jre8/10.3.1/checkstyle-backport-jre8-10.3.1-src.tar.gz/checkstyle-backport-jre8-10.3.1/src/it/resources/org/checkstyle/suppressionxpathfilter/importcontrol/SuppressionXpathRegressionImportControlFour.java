package org.checkstyle.suppressionxpathfilter.importcontrol;

import java.io.*;
import java.util.Scanner; //warn
import java.util.Arrays;


public class SuppressionXpathRegressionImportControlFour {

}
