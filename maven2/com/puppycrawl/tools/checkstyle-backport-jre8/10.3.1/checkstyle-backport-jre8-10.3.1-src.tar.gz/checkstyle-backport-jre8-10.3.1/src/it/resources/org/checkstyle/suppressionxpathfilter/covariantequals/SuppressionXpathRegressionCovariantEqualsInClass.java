package org.checkstyle.suppressionxpathfilter.covariantequals;

public class SuppressionXpathRegressionCovariantEqualsInClass {

    public boolean equals(SuppressionXpathRegressionCovariantEqualsInClass i) {  // warn
        return false;
    }

}
