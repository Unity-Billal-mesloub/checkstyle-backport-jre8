package org.checkstyle.suppressionxpathfilter.declarationorder;

public class SuppressionXpathRegressionDeclarationOrderOne {
    private int age;
    public String name;  //warn
}
