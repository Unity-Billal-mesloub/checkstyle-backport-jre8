package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

import static java.awt.Button.ABORT;
import static java.io.File.createTempFile;
// comments


// comments
import static javax.swing.WindowConstants.*; //warn

// comments

import com.google.checkstyle.test.chapter2filebasic.rule21filename.*; //warn
import com.google.checkstyle.test.chapter3filestructure.rule3sourcefile.*;
// comments

import com.google.common.reflect.*; //warn
import java.util.List;

// comments
import java.util.StringTokenizer; //warn
// comments

// comments
import java.util.concurrent.AbstractExecutorService; //warn

public class InputCustomImportOrder5 {
}
