package org.checkstyle.suppressionxpathfilter.importcontrol; //warn

import java.util.Scanner;

public class SuppressionXpathRegressionImportControlTwo {
}
