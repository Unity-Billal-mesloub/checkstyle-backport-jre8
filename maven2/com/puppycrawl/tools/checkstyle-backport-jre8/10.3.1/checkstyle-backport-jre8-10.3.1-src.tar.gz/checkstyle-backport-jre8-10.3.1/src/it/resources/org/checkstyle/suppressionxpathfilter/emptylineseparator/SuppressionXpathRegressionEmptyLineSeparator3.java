///////////////////////////////////////////////////
//HEADER
///////////////////////////////////////////////////
package org.checkstyle.suppressionxpathfilter.emptylineseparator;
import java.io.*;
class SuppressionXpathRegressionEmptyLineSeparator3 {
    public static final int FOO_CONST = 1;
    public void foo() {}
    public void foo1() {} // warn
}
