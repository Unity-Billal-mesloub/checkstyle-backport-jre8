package org.checkstyle.suppressionxpathfilter.avoidstarimport;

import static javax.swing.WindowConstants.*; // warn

public class SuppressionXpathRegressionAvoidStarImport1 {
}
