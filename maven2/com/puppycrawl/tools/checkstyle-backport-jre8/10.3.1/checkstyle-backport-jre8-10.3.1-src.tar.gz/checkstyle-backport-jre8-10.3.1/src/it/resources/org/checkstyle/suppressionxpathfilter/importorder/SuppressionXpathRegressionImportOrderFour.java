package org.checkstyle.suppressionxpathfilter.importorder;

import java.io.*;
import java.util.Set;
import static java.lang.Math.PI; // warn

public class SuppressionXpathRegressionImportOrderFour {
    // code
}
