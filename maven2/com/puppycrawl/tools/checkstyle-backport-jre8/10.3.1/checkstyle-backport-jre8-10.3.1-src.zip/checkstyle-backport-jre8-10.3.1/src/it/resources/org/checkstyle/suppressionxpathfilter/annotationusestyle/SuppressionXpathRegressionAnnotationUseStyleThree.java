package org.checkstyle.suppressionxpathfilter.annotationusestyle;

public class SuppressionXpathRegressionAnnotationUseStyleThree {
    @SuppressWarnings({"common",}) //warn
    public void foo() {

    }
}
