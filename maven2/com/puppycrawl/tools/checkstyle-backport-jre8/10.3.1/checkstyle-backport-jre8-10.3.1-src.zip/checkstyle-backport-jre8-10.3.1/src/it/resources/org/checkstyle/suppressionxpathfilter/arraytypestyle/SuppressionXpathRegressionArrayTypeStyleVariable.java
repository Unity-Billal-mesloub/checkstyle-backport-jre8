package org.checkstyle.suppressionxpathfilter.arraytypestyle;

public class SuppressionXpathRegressionArrayTypeStyleVariable {
    String strings[]; // warn
}
