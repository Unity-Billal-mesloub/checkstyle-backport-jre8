package org.checkstyle.suppressionxpathfilter.finalclass;

public class SuppressionXpathRegressionFinalClass1 { // warn
    private SuppressionXpathRegressionFinalClass1() {

    }
}
