package org.checkstyle.suppressionxpathfilter.avoidstarimport;

import java.util.Scanner;
import java.io.*;  // warn

public class SuppressionXpathRegressionAvoidStarImport2 {
}
